<?php

namespace Domains\Products\Actions;

use App\Models\Product;
use Domains\Products\DataTransferObjects\ProductsData;

final class ProductsAction
{
    /**
     * The function creates a new product using the provided data.
     * 
     * @param ProductsData data The parameter `` is an instance of the `ProductsData` class. It is
     * used to pass the data required to create a new product.
     */
    public function createProduct(ProductsData $data): void
    {
        Product::create($data->toArray());
    }

    /**
     * The function updates a product using the data provided.
     * 
     * @param product The  parameter is an instance of the Product model. It represents the
     * product that needs to be updated in the database.
     * @param ProductsData data The  parameter is an instance of the ProductsData class. It is
     * used to provide the updated data for the product. The ProductsData class likely contains methods
     * to retrieve and manipulate the data related to a product. In this case, the toArray() method is
     * called on the  object to convert
     */
    public function updateProduct($product, ProductsData $data): void
    {
        $product->update($data->toArray());
    }

    /**
     * The deleteProduct function deletes a given product.
     * 
     * @param product The parameter "product" is an instance of a product object that you want to
     * delete.
     */
    public function deleteProduct($product): void
    {
        $product->delete();
    }

    /**
     * The function `uploadProductPhoto` updates the `product_image` attribute of a given ``
     * with the value of `->product_image`.
     * 
     * @param product The  parameter is an instance of the Product model. It represents the
     * product for which the photo is being uploaded.
     * @param data The  parameter is an object that contains the data for the product photo. It
     * should have a property called "product_image" which represents the image file that needs to be
     * uploaded.
     */
    public function uploadProductPhoto($product, $data): void
    {
        $product->update(['product_image' => $data->product_image]);
    }
}
