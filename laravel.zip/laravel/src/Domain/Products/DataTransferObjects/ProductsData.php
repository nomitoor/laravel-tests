<?php

namespace Domains\Products\DataTransferObjects;

use Spatie\LaravelData\Data;
use Spatie\LaravelData\Attributes\Validation\Max;
use Spatie\LaravelData\Attributes\Validation\Unique;

class ProductsData extends Data
{
    public function __construct(
        #[Max(50), Unique('products')]
        readonly public string $title,
        #[Max(255)]
        readonly public string $description,
        #[Max(1000)]
        readonly public ?string $product_image
    ) {
    }
}
