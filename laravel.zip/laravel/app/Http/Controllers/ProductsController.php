<?php

namespace App\Http\Controllers;

use App\Models\Product;
use Illuminate\Http\Request;
use Domains\Products\Actions\ProductsAction;
use Domains\Products\DataTransferObjects\ProductsData;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Response;

class ProductsController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index(): JsonResponse
    {
        Product::paginate();

        return response()->json([
            'status' => Response::HTTP_CREATED,
            'message' => 'All Products found!',
            'products' => Product::paginate(),
        ], Response::HTTP_CREATED);
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(ProductsData $data, ProductsAction $action): JsonResponse
    {
        $action->createProduct($data);

        return response()->json([
            'status' => Response::HTTP_CREATED,
            'message' => 'Product Created successfully'
        ], Response::HTTP_CREATED);
    }

    /**
     * Display the specified resource.
     */
    public function show(Product $product): JsonResponse
    {
        return response()->json([
            'status' => Response::HTTP_CREATED,
            'message' => 'Product Found!',
            'product' => $product,
        ], Response::HTTP_CREATED);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Product $product, ProductsData $data): JsonResponse
    {
        app(ProductsAction::class)->updateProduct($product, $data);

        return response()->json([
            'status' => Response::HTTP_CREATED,
            'message' => 'Product updated successfully'
        ], Response::HTTP_CREATED);
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Product $product): JsonResponse
    {
        app(ProductsAction::class)->deleteProduct($product);

        return response()->json([
            'status' => Response::HTTP_CREATED,
            'message' => 'Product deleted successfully'
        ], Response::HTTP_CREATED);
    }

    public function productPhoto(Product $product, Request $data): JsonResponse
    {
        app(ProductsAction::class)->uploadProductPhoto($product, $data);

        return response()->json([
            'status' => Response::HTTP_CREATED,
            'message' => 'Product photo updated successfully'
        ], Response::HTTP_CREATED);
    }
}
